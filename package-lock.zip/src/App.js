
import SearchBar from './Components/SearchBar';
import logo from './logo.svg';
//import Homepage from './Pages/Home';
//import Registration from './Components/Registration';
//import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
//import "../src/App.css"
import Homepage from './Pages/Home';

function App() {
 

  return (
    <div>
      <Homepage/>
    </div>
  );
}

export default App;
