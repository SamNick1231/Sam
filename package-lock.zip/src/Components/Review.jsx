import React from 'react';
import "../styles/navbarstyle.css";
import ab from "../Images/rev1.jpg";
import bc from "../Images/rev2.jpg";
import ca from "../Images/sh.jpeg";


export default function Review() {

    return(
        <section className="reviews" id="reviews">
            <div className="heading">
                <span>Reviews</span>
                <h1>what Our customer Say</h1>
            </div>
            <div className="reviews-container">
                <div className="box">
                    <div className="rev-img">
                    <img src={ab} alt=""></img>
                </div>
                <h2>Jenny</h2>
                <div className="stars">
                    <i className='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star-half'></i>
                </div>
                <p>Amazing feeling .. Loved it</p>
                </div>

                <div className="box">
                    <div className="rev-img">
                    <img src={bc} alt=""></img>
                </div>
                <h2>Preetam Noel</h2>
                <div className="stars">
                    <i className='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                
                </div>
                <p>Worth booking Good service</p>
                </div>

                <div className="box">
                    <div className="rev-img">
                    <img src={ca} alt=""></img>
                </div>
                <h2>Shwe..</h2>
                <div className="stars">
                    <i className='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star-half'></i>
                </div>
                <p>Deliverd on Time.</p>
                </div>
            </div>
        </section>
    )

}