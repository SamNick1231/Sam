import React from 'react';
import "../styles/navbarstyle.css"
import{Link, Switch ,Route} from "react-router-dom"
import car1 from "../Images/car1.jpg"
import car2 from "../Images/car2.jpg"
import car3 from "../Images/car3.jpg"
import car4 from "../Images/car4.jpg"
import car5 from "../Images/car5.jpg"
import car6 from "../Images/car6.jpg"

export default function Service() {
    return (
    <section className="services" id="services">
    <div className="heading">
        <span>Best Services</span>
        <h1>Explore Our Top Deals <br/>From Top Rated Dealers  </h1> 
        
        </div><br />
        <div className="services-container">
            <div className='box'>
            <div className="box-img">
                <img src={car1} alt="" />
            </div>
            <p>2017</p>
            <h3>2018 Honda Civic</h3>
            <h2>$58500 | $354 <span>/month</span></h2>
            <Link className='btn' to="/">Rent Now</Link>
            </div>

        <div className="box">
            <div className="box-img">
                <img src={car2} alt=""/>
            </div>
            <p>2017</p>
            <h3>2018 Honda Civic</h3>
            <h2>$58500 | $354 <span>/month</span></h2>
            <Link className='btn' to="/">Rent Now</Link>
        </div>

        <div className="box">
            <div className="box-img">
                <img src={car3} alt=""/>
            </div>
            <p>2017</p>
            <h3>2018 Honda Civic</h3>
            <h2>$58500 | $354 <span>/month</span></h2>
            <Link className='btn' to="/">Rent Now</Link>
        
        </div>

        <div className="box">
            <div className="box-img">
                <img src={car4} alt=""/>
            </div>
            <p>2017</p>
            <h3>2018 Honda Civic</h3>
            <h2>$58500 | $354 <span>/month</span></h2>
            <Link className='btn' to="/">Rent Now</Link>
        </div>

        <div className="box">
            <div className="box-img">
                <img src={car5} alt=""/>
            </div>
            <p>2017</p>
            <h3>2018 Honda Civic</h3>
            <h2>$58500 | $354 <span>/month</span></h2>
            <Link className='btn' to="/">Rent Now</Link>
        </div>
        <div className="box">
            <div className="box-img">
                <img src={car6} alt=""/>
            </div>
            <p>2017</p>
            <h3>2018 Honda Civic</h3>
            <h2>$58500 | $354 <span>/month</span></h2>
            <Link className='btn' to="/">Rent Now</Link>
        </div>
        </div>
        </section>
    )
}