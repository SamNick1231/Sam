import React from 'react';
import "../styles/navbarstyle.css"
import { Link } from 'react-router-dom';
export default function Copyright() {
  return (

<div className="copyright">
    <p>&#169; CarpoolVenom All Right Reserved</p>
    <div className="social">
        <nav>
        <Link className='bx bxl-facebook' to="/"></Link>
        <Link className='bx bxl-twitter' to="/"></Link>
        <Link className='bx bxl-instagram' to="/"></Link>
        </nav>
    </div>
</div>
 )
}