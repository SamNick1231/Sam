import React from 'react';
import ride from "../Images/about.png"
import "../styles/navbarstyle.css"
import{Link, Switch ,Route} from "react-router-dom"

export default function AboutSection() {
  return (
    <section className="about" id='about'>
      <div className='heading'>
        <span>About us</span>
        <h1 >
        Comfortable rides from reliable and experienced people
       </h1>
      </div>
      <div className="about-container">
        <div className='about-img'>
           <img src={ride} alt="" />
        </div>
        <div className='about-text'>
          <span> About Us</span>
          <p>
            We are a car rental service available to you 24/7. We provide the most
            confortable and cheapest rides in the country. Hook us up for your trips and
            get the best confort can offer.
          </p>
          <nav>
          <Link className='btn' to="/">Learn More</Link>
          </nav>
        </div>  
      </div>
    </section>
  );
}


   