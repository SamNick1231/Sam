import React from 'react';
import "../styles/navbarstyle.css"

export default function RideSection() {
    return (
    <section className="ride" id="ride">
    <div className="heading">
        <span>How Its Work</span>
        <h1>Rent With 3 Easy Steps</h1>
    </div>
    <div className="ride-container">
            <div className="box">
                <i className='bx bxs-map'></i>
                <h2>Choose A Location</h2>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt ut labore et dolore magna aliqua</p>
            </div>

            <div className="box">
                <i className='bx bxs-calendar-check'></i>
                <h2>Pick-Up Date</h2>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt ut labore et dolore magna aliqua</p>
            </div>

            <div className="box">
            <i className='bx bxs-calendar-star'></i>
                <h2>Book A Car</h2>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt ut labore et dolore magna aliqua</p>
            </div>

        </div>
        </section>
    )
}