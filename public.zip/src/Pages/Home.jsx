import React from 'react'
import AboutSection from '../Components/About';
import Copyright from '../Components/Copywright';
import HomeSection from '../Components/HomeSection';
import Navbar from '../Components/Navbar';
import Newsletter from '../Components/Newsletter';
import Review from '../Components/Review';
import RideSection from '../Components/RideSection';
import Service from '../Components/Service';

const 
Homepage = () => {
  return (
    <div>
        <Navbar/>
        <HomeSection/>
        <RideSection/>
        <Service/>
        <AboutSection></AboutSection>
        <Review></Review>
        <Newsletter/>
    <Copyright></Copyright>
  
    </div>
  )
}

export default Homepage; 