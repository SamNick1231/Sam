import React from 'react'
import "../styles/navbarstyle.css"
import img1 from '../Images/1544267.jpg'
import{Link, Switch ,Route,} from "react-router-dom"
import HomeSection from './HomeSection'
import RideSection from './RideSection'
import Service from './Service'
import AboutSection from './About'
import Review from './Review'
import Registration from './Registration'




const Navbar = () => {
  

  return (
    <div className='container'>
        <header className='wrapper'>
            <img src={img1} alt=".." className='img'/>  
           <div className="bx bx-menu" id="menu-icon"></div>
           <nav className='navbar'>
        <Link className='navbarlink' to="/">Home</Link>
        <Link className='navbarlink' to="/Ride">Ride</Link>
        <Link className='navbarlink' to="/Services">Services</Link>
        <Link className='navbarlink' to="/About">About</Link>
        <Link className='navbarlink' to="/Reviews">Reviews</Link>
        </nav>
        
        <nav className='head-btn'>
        
        <Link className='signin' to="/Registration"> SignIn</Link>
        </nav>
        
        </header> 
        <Switch>
        <Route path="/Home" exact component={HomeSection}/>
        <Route path="/Ride" exact component={RideSection}/>
        <Route path="/Services" exact component={Service}/>
        <Route path="/About" exact component={AboutSection}/>
        <Route path="/Reviews" exact component={Review}/>
        
          <div className='inner'>
        <Route path="/Registration" exact component={Registration}/>
        </div>
      
  
      </Switch>
    </div>
  )
}

export default Navbar