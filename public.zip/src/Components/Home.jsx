import React from 'react';
function Home() {
    return (  
        <div>
           <h2 style={{color:"orangered"}}> Login Successfully</h2>
        </div>
    );
}

export default Home;