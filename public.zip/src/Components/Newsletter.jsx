import React from 'react';
import { Link } from 'react-router-dom';
import "../styles/navbarstyle.css"

export default function Newsletter() {
  return (
   
<section className="newsletter">
    <h2>Subscribe to Newsletter</h2>
    <div className="box">
        <input type="text" placeholder="Enter your Email..."></input>
            <Link className='btn' to="/">Subscribe</Link>
    </div>
</section>
  )
}