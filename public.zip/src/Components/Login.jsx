import { useState, useEffect } from "react";
import { Alert } from "react-bootstrap";
import "./login.css";
import "../styles/navbarstyle.css";
import Home from "./Home";


function Login() {
  const [formValues, setFormValues] = useState({
       email: "", 
       password: "" });
  const [formErrors, setFormErrors] = useState({});
  const [isSubmit, setIsSubmit] = useState(false);
 const [home,setHome] =useState(true);
const {email,password}=formValues;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...formValues, [name]: value });
  };

  function handleLogin(e) {
    e.preventDefault();
    setFormErrors(validate(formValues));
    let mail=localStorage.getItem("Email").replace(/"/g,"");
    let pass=localStorage.getItem("Password").replace(/"/g,"");
    
    if(!email || !password){
        setIsSubmit(true);
        console.log("Empty");
    }else if(password!== pass || email!== mail){
        setIsSubmit(true);
    }else {
        setHome(!home);
        setIsSubmit(false);
  
  };
  }
  useEffect(() => {
    console.log(formErrors);
    if (Object.keys(formErrors).length === 0 && isSubmit) {
      console.log(formValues);
    }
  }, [formErrors]);
  const validate = (values) => {
    const errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    
    if (!values.email) {
      errors.email = "Email is required!";
    } else if (!regex.test(values.email)) {
      errors.email = "This is not a valid email format!";
    }
    if (!values.password) {
      errors.password = "Password is required";
    } else if (values.password.length < 4) {
      errors.password = "Password must be more than 4 characters";
    } else if (values.password.length > 10) {
      errors.password = "Password cannot exceed more than 10 characters";
    }
    return errors;
  };
 

  return (
    
    <div id="container">
     
  {home ? (
      <form onSubmit={handleLogin}>
        <h1>Login </h1>
        <h4>Experience Your Best Ride</h4>
        <div className="ui divider"></div>
        <div className="ui form">
          
          <div className="field">
            <label>Email</label>
            <br/>
            <input
              type="text"
              name="email"
              placeholder="Email"
              value={formValues.email}
              onChange={handleChange}
            />
          </div>
          <p>{formErrors.email}</p>
          <div className="field">
            <label>Password</label>
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={formValues.password}
              onChange={handleChange}
            />
          </div>
          <p>{formErrors.password}</p>
          <button className="fluid ui button blue">Submit</button>
        </div>
        {isSubmit && (
                    <Alert color= "primary" variant='danger'>
                        Please fill Correct Info
                        </Alert>
        )}
        
        </form>
        ):(
          
            <Home/>
            
        )}
    
    </div>
  );
}

export default Login;