import React from 'react'
import "../styles/navbarstyle.css"
import ios from "../Images/ios.png"
import andriod from "../Images/andriod.png"

const HomeSection=()=>{
    return(
        <section className='home' id='home'  >
            
            <div className='text'>
                <h1><span>Looking</span> to <br />rent a car</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores, aut ex quibusdam repudiandae ullam odit veritatis ipsa? Corrupti commodi dolores est non quibusdam odit, blanditiis, exercitationem ab, expedita numquam vero.</p>
                <div className='app-stores'>
                 <img src={ios} alt="" />
                 <img src={andriod} alt="" />
                </div>
            </div>
            <div className='form-container'>
                <form action="">
                  <div className='input-box'>
                      <span>Location</span>
                      <input type="search" name='' id='' placeholder='Search'/>
                  </div>
                  <div className='input-box'>
                      <span>Pick-Up Date</span>
                      <input type="date" name='' id=''/>
                  </div>
                  <div className='input-box'>
                      <span>Return Date</span>
                      <input type="date" name='' id=''/>
                  </div>
                  <input type="Submit" name='' id='' className='btn' />
                </form>
            </div>
        </section>

    )
}
export default HomeSection;